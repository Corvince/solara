Please go to https://solara.dev/docs/howto/contribute for more information.
