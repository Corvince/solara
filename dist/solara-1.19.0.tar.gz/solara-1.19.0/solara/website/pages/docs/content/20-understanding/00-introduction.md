# Introduction

Solara builds on existing technologies. If you are new to Solara or some of the underlying technologies, you may feel lost at times.
These 'understanding' guides are meant to help you understand topics at a deeper level and how they connect to Solara.
