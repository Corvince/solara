# Rules of hooks

For now, we refer to the [ReactJS documentation](https://reactjs.org/docs/hooks-rules.html).
