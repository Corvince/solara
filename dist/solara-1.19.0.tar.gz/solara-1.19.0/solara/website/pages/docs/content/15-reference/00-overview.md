# Reference documentation

Our reference documentation informs you about how certain parts in Solara work.

The [API docs](/api) are considered part of the reference documentation, but because of the
large content has its own page.
