A bundle that is used for solara-server that includes all static assets we need.

For a dev install, use something like so that the Solara CDN proxy picks up the bundle locally:

    $ npm install
    $ npm run build
    $ npm run devlink
