"CDN assets for Solara"
__version__ = "1.19.0"
