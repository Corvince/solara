// eslint-disable-next-line @typescript-eslint/naming-convention
declare interface Window {
  define: any;
  requirejs: any;
}
