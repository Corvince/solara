import solara

title = "Fruit home"


@solara.component
def Page():
    return solara.Success("Yay")
