# Multi page app using regular ipywidget

 * [Record views (widget based)](/views)
 * [Record likes (widget based)](/likes)
 * [Volume (uses component)](/volume)
 * [Color (uses widget in notebook)](/color)
