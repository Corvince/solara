import solara.website.pages.api.griddraggable as mod

Page = mod.Page
