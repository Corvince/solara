import solara.website.pages.api.use_route as mod

routes = mod.routes
Page = mod.Page
