import solara.website.pages.api.button as mod

Page = mod.Page
